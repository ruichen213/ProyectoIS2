package pruebaisi2.modelo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 *
 * @author cuent
 */
public class Camping {
    private ArrayList<Actividad> actividades;
    private ArrayList<Cliente> clientes;
    private ArrayList<Parcela> parcelas;
    private ArrayList<Reserva> reservas;
    private ArrayList<Tienda> tiendas;
    private int idCliente;
    
    
    public Camping(){
        actividades = new ArrayList<Actividad>();
        clientes = new ArrayList<Cliente>();
        parcelas = new ArrayList<Parcela>();
        reservas = new ArrayList<Reserva>();
        tiendas = new ArrayList<Tienda>();
    }
    
    /*
        Esta funcion anyade al camping algunos valores (actividades, 
        clientes, parcelas, reservas, tiendas)
    */
    public void cargarDatos(){
        Actividad actividad1 = new Actividad("Piscina", "10/10/2023", "12:30", "libre");
        Actividad actividad2 = new Actividad("Fronton", "09/11/2023", "11:30", "ocupada");
        Actividad actividad3 = new Actividad("Juegos Sociales", "08/08/2023", "10:30", "libre");
        Actividad actividad4 = new Actividad("Piscina", "12/12/2023", "12:30", "libre");
        Actividad actividad5 = new Actividad("Fronton", "09/12/2023", "11:30", "ocupada");
        Actividad actividad6 = new Actividad("Juegos Sociales", "10/08/2023", "10:30", "libre");
        actividades.add(actividad1);
        actividades.add(actividad2);
        actividades.add(actividad3);
         actividades.add(actividad4);
        actividades.add(actividad5);
        actividades.add(actividad6);
        
        //Dan valor al indice de las actividades en funcion de su posicion+1 en el ArrayList
        actividad1.setId(actividades.indexOf(actividad1)+1);
        actividad2.setId(actividades.indexOf(actividad2)+1);
        
        Reserva reserva1 = new Reserva(1,1, "12/12/2020", "20/12/2020", true);
        Reserva reserva2 = new Reserva(2,2, "07/06/2012", "07/07/2012", true);
        reservas.add(reserva1);
        reservas.add(reserva2);
        
        //Dan valor al indice de las reservas en funcion de su posicion+1 en el ArrayList
        reserva1.setId(reservas.indexOf(reserva1)+1);
        reserva2.setId(reservas.indexOf(reserva2)+1);
        
        Tienda t1 = new Tienda ("Suprema",20);
        Tienda t2 = new Tienda ("Deluxe",50);
        tiendas.add(t1);
        tiendas.add(t2);
        
        Parcela parcela1 = new Parcela (1,100,true,20,true);
        Parcela parcela2 = new Parcela (2,50,true,15,false);
        Parcela parcela3 = new Parcela (3,20,true,10,true);
        parcelas.add(parcela1);
        parcelas.add(parcela2);
        parcelas.add(parcela3);
        
        Cliente cliente1 = new Cliente("Jose", "1111");
        cliente1.addActividad(actividad1);
        cliente1.addParcela(parcela1);
        Cliente cliente2 = new Cliente("Pepe", "2222");
        cliente2.addActividad(actividad2);
        cliente2.addParcela(parcela2);
        Cliente cliente3 = new Cliente("Marcos", "3333");
        cliente3.addActividad(actividad3);
        cliente3.addParcela(parcela3);
        clientes.add(cliente1);
        clientes.add(cliente2);
        clientes.add(cliente3);
        
        //Dan valor al indice de los clientes en funcion de su posicion+1 en el ArrayList
//        cliente1.setId(clientes.indexOf(cliente1)+1);
//        cliente2.setId(clientes.indexOf(cliente2)+1);
//        cliente3.setId(clientes.indexOf(cliente3)+1);
    }
    /*
        Para qusitar
    */
    public int averiguarIdActividadCliente(String[] partes){
        int k = 0;
        Cliente c1 = clientes.get(idCliente);
        k = c1.getIdActividad(partes);
        return k;
    }
    
    public void cancelarActividadCliente(int idActividad){
        Cliente c1 = clientes.get(idCliente);
        Actividad a1 = actividades.get(idActividad);
        c1.quitarActividad(a1);
    }
    
    public int getNumActividadesCliente(){
        Cliente c1 = clientes.get(idCliente);
        return c1.getNumActividades();
    }
    
    public void addActividadToCliente(int idActividad){
        Cliente c1 = clientes.get(idCliente);
        Actividad a1 = actividades.get(idActividad);
        c1.addActividad(a1);
    }
    
    public String getClienteUsuario(int i){
        Cliente c1 = clientes.get(i);
        return c1.getUsuario();
    }
    
    public String getClienteContrasenya(int i){
        Cliente c1 = clientes.get(i);
        return c1.getContrasenya(); }
    
    public int averiguamosCliente(String u, String p){
        int pos = 0;
        
        for (int i = 0; i < clientes.size(); i++){
            if (u.equals(getClienteUsuario(i)) && p.equals(getClienteContrasenya(i))){
                pos = i;
            }
        }
        
        return pos;
    }
    
    public void retirarParcela(int id_){
        // ?
    }
    
    public int cantidadActividades(){
        return actividades.size();
    }
    
    public void setIdCliente(int i){
        this.idCliente = i;
    }
    
    public int getIdCliente(){
        return idCliente;
    }
    /*
        Para anyadir
    */
    public void anyadirActividad(Actividad a){
        actividades.add(a);
    }
    
    public String mostrarActividad(int i){
        String cadena = "";
        Actividad a1 = actividades.get(i);
        
        cadena = a1.getTipoActividad() + ", " + a1.getDia()
                + ", " + a1.getHora();
        
        return cadena;
    }
    
    public String getDiaActividad(int i){
        String dia = "";
        Actividad a1 = actividades.get(i);
        
        dia = a1.getDia();
        
        return dia;
    }
    
    public void setActividadOcupada(int i){
        Actividad a1 = actividades.get(i);
        a1.setOcupada();
    }
    
    public String getFechaActividad(int i){
        String fecha = "";
        Actividad a1 = actividades.get(i);
        
        fecha = a1.getFecha();
        
        return fecha;
    }
    
     public String getTipoActividad(int i){
        String tipoActividad = "";
        Actividad a1 = actividades.get(i);
        
        tipoActividad = a1.getTipoActividad();
        
        return tipoActividad;
    }
     
    public String getEstadoActividad(int i){
        String estado = "";
        Actividad a1 = actividades.get(i);
        
        estado = a1.getEstado();
        
        return estado;
    }
    
    public void anyadirReserva(Reserva e){
        reservas.add(e);
    }

    public void anyadirParcela(Parcela e){
        parcelas.add(e);
    }
    
    /*
        Getters
    */
    public ArrayList<Reserva> getReservas(){
        return reservas;
    }
    
    public ArrayList<Parcela> getParcelas(){
        return parcelas;
    }
    
    public Parcela getParcela(int index){
        return parcelas.get(index);
    }
    
    public ArrayList<Tienda> getTiendas(){
        return tiendas;
    }
    
    public Tienda getTienda(int indice){
        return tiendas.get(indice);
    }
     
    public Parcela getLastPar()
    {
        return parcelas.get(parcelas.size()-1);     
    }

    public Reserva getLastRes()
    {
        return reservas.get(reservas.size()-1);
    }
    
    public int getNumTiendas(){
        return tiendas.size();
    }
    
    public int getLastIdParcela(){
        return parcelas.get(parcelas.size()-1).getId();
    }
    
    public int getLastIdCliente(){
        return clientes.get(clientes.size()-1).getId();
    }
    
    public int getNumParcelas(){
        return parcelas.size();
    }
    
    public int getIdCliente(String nombre){
        int id = 0;
        
        for (int i = 0; i < clientes.size(); i++){
            if(clientes.get(i).getNombre().equalsIgnoreCase(nombre)){
                id = clientes.get(i).getId();
            }
        }
        
        return id;
    }
    
    
    public String getFechaEntrada (int idCliente){
        String fechaEntrada = "";
        
        for (int i = 0; i < reservas.size(); i++){
            if (reservas.get(i).getIdCliente() == idCliente){
                fechaEntrada = reservas.get(i).getFechaInicio();
            }
        }
        
        return fechaEntrada;
    }
            
    public int getLastId(){
        int size = actividades.size();
        if (size > 0) {
            return actividades.get(2).getId();
        } else {
            // Manejar el caso en el que la lista esté vacía
            return -1; // o algún valor predeterminado apropiado
        }
    }
    public boolean esFechaValida(String fechaTexto) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        formatoFecha.setLenient(false); // Esto hace que el parseo sea estricto

        try {
            formatoFecha.parse(fechaTexto); // Intenta parsear la fecha
            return true; // La fecha es válida
        } catch (ParseException e) {
            return false; // La fecha no es válida
        }
    }
    public boolean esHoraValida(String horaTexto) {
        SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm");
        formatoHora.setLenient(false); // Esto hace que el parseo sea estricto

        try {
            formatoHora.parse(horaTexto); // Intenta parsear la hora
            return true; // La hora es válida
        } catch (ParseException e) {
            return false; // La hora no es válida
        }
    }
}
